""" Functionality for manipulating Amber input files """
from .mdin import Mdin

__all__ = ['Mdin']
