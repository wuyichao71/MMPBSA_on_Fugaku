""" Utilities to aid with type hinting """
from typing import Union

InputDataType = Union[int, float, str]
